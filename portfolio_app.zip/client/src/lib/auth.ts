import { queryClient } from './queryClient';
import { apiRequest } from './queryClient';

export interface User {
  id: number;
  username: string;
}

export interface LoginCredentials {
  username: string;
  password: string;
}

export async function login(credentials: LoginCredentials): Promise<User> {
  const res = await apiRequest('POST', '/api/auth/login', credentials);
  const data = await res.json();
  
  // Invalidate user query to refetch with new auth state
  queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
  
  return data.user;
}

export async function logout(): Promise<void> {
  await apiRequest('POST', '/api/auth/logout');
  
  // Invalidate user query after logout
  queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
}

export function useCurrentUser() {
  return queryClient.getQueryData<{ user: User }>(['/api/auth/user'])?.user;
}

export function isAuthenticated(): boolean {
  return !!useCurrentUser();
}
