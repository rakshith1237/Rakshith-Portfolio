import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from './queryClient';
import { 
  Profile, Project, Skill, GithubRepo, InsertProfile, InsertProject, InsertSkill
} from '@shared/schema';

// Profile hooks
export function useProfile() {
  return useQuery<Profile>({
    queryKey: ['/api/profile'],
  });
}

export function useUpdateProfile() {
  return useMutation({
    mutationFn: async (profile: InsertProfile) => {
      const res = await apiRequest('PUT', '/api/admin/profile', profile);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
    }
  });
}

// Projects hooks
export function useProjects() {
  return useQuery<Project[]>({
    queryKey: ['/api/projects'],
  });
}

export function useCreateProject() {
  return useMutation({
    mutationFn: async (project: InsertProject) => {
      const res = await apiRequest('POST', '/api/admin/projects', project);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    }
  });
}

export function useUpdateProject() {
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertProject> }) => {
      const res = await apiRequest('PUT', `/api/admin/projects/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    }
  });
}

export function useDeleteProject() {
  return useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/admin/projects/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/projects'] });
    }
  });
}

// Skills hooks
export function useSkills() {
  return useQuery<Skill[]>({
    queryKey: ['/api/skills'],
  });
}

export function useCreateSkill() {
  return useMutation({
    mutationFn: async (skill: InsertSkill) => {
      const res = await apiRequest('POST', '/api/admin/skills', skill);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/skills'] });
    }
  });
}

export function useUpdateSkill() {
  return useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertSkill> }) => {
      const res = await apiRequest('PUT', `/api/admin/skills/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/skills'] });
    }
  });
}

export function useDeleteSkill() {
  return useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/admin/skills/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/skills'] });
    }
  });
}

// Tools hooks
export function useTools() {
  return useQuery<{ id: number; name: string; icon: string }[]>({
    queryKey: ['/api/tools'],
  });
}

// GitHub hooks
export function useGithubRepos() {
  return useQuery<GithubRepo[]>({
    queryKey: ['/api/github-repos'],
  });
}

export function useSyncGithubRepos() {
  return useMutation({
    mutationFn: async (username: string) => {
      const res = await apiRequest('POST', '/api/admin/github-sync', { username });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/github-repos'] });
      queryClient.invalidateQueries({ queryKey: ['/api/profile'] });
    }
  });
}

// Social links hooks
export function useSocialLinks() {
  return useQuery({
    queryKey: ['/api/social-links'],
  });
}
