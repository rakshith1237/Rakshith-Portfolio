import { useGithubRepos, useProfile } from '@/lib/hooks';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Star, GitFork, ExternalLink, Clock } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function GithubSection() {
  const { data: repos, isLoading } = useGithubRepos();
  const { data: profile } = useProfile();

  if (isLoading) {
    return (
      <section className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-extrabold text-foreground">
              GitHub Projects
            </h2>
            <p className="mt-4 text-xl text-muted-foreground max-w-2xl mx-auto">
              Automatically synced from my GitHub account.
            </p>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1, 2, 3].map(i => (
              <Card key={i}>
                <CardContent className="p-6">
                  <Skeleton className="h-7 w-3/4 mb-4" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-5/6 mb-6" />
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                  <Skeleton className="h-5 w-1/3" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    );
  }

  // If no repos and no GitHub username, don't show the section
  if ((!repos || repos.length === 0) && !profile?.githubUsername) {
    return null;
  }

  return (
    <section className="py-16 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-extrabold text-foreground">
            GitHub Projects
          </h2>
          <p className="mt-4 text-xl text-muted-foreground max-w-2xl mx-auto">
            Automatically synced from my GitHub account.
          </p>
        </div>
        
        {(!repos || repos.length === 0) ? (
          <div className="text-center py-10">
            <p className="text-muted-foreground">
              No GitHub repositories found. 
              {profile?.githubUsername && (
                <a 
                  href={`https://github.com/${profile.githubUsername}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ml-2 text-primary hover:underline"
                >
                  View GitHub Profile
                </a>
              )}
            </p>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {repos.map(repo => (
              <Card key={repo.id} className="hover:shadow-md transition-shadow duration-200">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <h3 className="text-lg font-semibold text-card-foreground">{repo.name}</h3>
                    <div className="flex items-center">
                      <span className="text-muted-foreground text-sm flex items-center mr-4">
                        <Star className="h-4 w-4 mr-1" />
                        {repo.stars}
                      </span>
                      <span className="text-muted-foreground text-sm flex items-center">
                        <GitFork className="h-4 w-4 mr-1" />
                        {repo.forks}
                      </span>
                    </div>
                  </div>
                  
                  <p className="mt-3 text-muted-foreground text-sm">
                    {repo.description || 'No description provided.'}
                  </p>
                  
                  <div className="mt-4 flex flex-wrap gap-2">
                    {repo.language && (
                      <Badge variant="secondary">
                        {repo.language}
                      </Badge>
                    )}
                    {repo.topics && repo.topics.slice(0, 3).map((topic, i) => (
                      <Badge key={i} variant="outline">
                        {topic}
                      </Badge>
                    ))}
                  </div>
                  
                  <div className="mt-4 flex justify-between items-center">
                    <div className="text-xs text-muted-foreground flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      {formatDistanceToNow(new Date(repo.updatedAt), { addSuffix: true })}
                    </div>
                    <a 
                      href={repo.url} 
                      className="text-primary hover:text-primary/90 text-sm font-medium flex items-center"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      View Repository
                      <ExternalLink className="h-4 w-4 ml-1" />
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
