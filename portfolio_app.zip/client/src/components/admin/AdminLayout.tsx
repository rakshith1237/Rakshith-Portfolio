import { useEffect, useState } from 'react';
import { Link, useLocation, useRoute } from 'wouter';
import { logout } from '@/lib/auth';
import { useProfile } from '@/lib/hooks';
import { ThemeProvider } from '@/components/ui/theme-provider';
import { Button } from '@/components/ui/button';
import { 
  LayoutDashboard, User, FolderKanban, Award, Github, LogOut, 
  ChevronRight, Menu, X, Sun, Moon 
} from 'lucide-react';
import { useTheme } from '@/components/ui/theme-provider';
import { cn } from '@/lib/utils';
import { Toaster } from '@/components/ui/toaster';

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [location, navigate] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { data: profile } = useProfile();
  const { theme, setTheme } = useTheme();

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Logout failed', error);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="bg-background border-b border-border z-10">
        <div className="flex h-16 items-center px-4 lg:px-6">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden"
          >
            {isMobileMenuOpen ? (
              <X className="h-6 w-6" />
            ) : (
              <Menu className="h-6 w-6" />
            )}
            <span className="sr-only">Toggle menu</span>
          </Button>
          
          <div className="flex items-center gap-2 font-semibold">
            <Link href="/admin" className="flex items-center">
              <LayoutDashboard className="h-5 w-5 text-primary mr-2" />
              <span className="hidden sm:inline-block">Portfolio Admin</span>
            </Link>
          </div>
          
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            
            <Link href="/" target="_blank" rel="noopener noreferrer">
              <Button variant="outline" size="sm" className="hidden sm:flex">
                View Site
                <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
            
            <Button variant="ghost" size="icon" onClick={handleLogout}>
              <LogOut className="h-5 w-5" />
              <span className="sr-only">Logout</span>
            </Button>
          </div>
        </div>
      </header>
      
      <div className="flex flex-1">
        {/* Sidebar */}
        <aside className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 transform bg-card border-r border-border pt-16 transition-transform duration-300 lg:static lg:translate-x-0",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        )}>
          <nav className="p-4 space-y-2">
            <p className="text-xs font-semibold text-muted-foreground tracking-wider uppercase mb-2 px-2">Dashboard</p>
            <NavLink href="/admin" icon={<LayoutDashboard className="h-5 w-5" />}>
              Overview
            </NavLink>
            <p className="text-xs font-semibold text-muted-foreground tracking-wider uppercase mt-6 mb-2 px-2">Content Management</p>
            <NavLink href="/admin/profile" icon={<User className="h-5 w-5" />}>
              Profile
            </NavLink>
            <NavLink href="/admin/projects" icon={<FolderKanban className="h-5 w-5" />}>
              Projects
            </NavLink>
            <NavLink href="/admin/skills" icon={<Award className="h-5 w-5" />}>
              Skills
            </NavLink>
            <NavLink href="/admin/github" icon={<Github className="h-5 w-5" />}>
              GitHub Integration
            </NavLink>
            <div className="pt-6 pb-2 px-2">
              <div className="rounded-lg bg-muted p-3">
                <div className="flex items-center">
                  <User className="h-10 w-10 text-primary p-2 bg-primary/10 rounded-full" />
                  <div className="ml-3">
                    <p className="text-sm font-medium">{profile?.name || 'Admin User'}</p>
                    <p className="text-xs text-muted-foreground">Administrator</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  className="w-full mt-3 text-sm h-8 justify-start text-muted-foreground" 
                  onClick={handleLogout}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            </div>
          </nav>
        </aside>
        
        {/* Main content */}
        <main className="flex-1 p-4 md:p-6 overflow-y-auto pb-16">
          {children}
        </main>
      </div>
      
      <Toaster />
    </div>
  );
}

interface NavLinkProps {
  href: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

function NavLink({ href, icon, children }: NavLinkProps) {
  const [isActive] = useRoute(href);
  
  return (
    <Link href={href}>
      <div className={cn(
        "flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors cursor-pointer",
        isActive 
          ? "bg-primary/10 text-primary" 
          : "text-muted-foreground hover:bg-muted hover:text-foreground"
      )}>
        {icon}
        <span className="ml-3">{children}</span>
      </div>
    </Link>
  );
}
