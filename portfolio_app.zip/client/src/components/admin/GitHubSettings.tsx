import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useSyncGithubRepos, useProfile, useGithubRepos } from '@/lib/hooks';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Loader2, AlertCircle, Github, RefreshCw } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const githubFormSchema = z.object({
  username: z.string().min(1, 'GitHub username is required')
});

type GitHubFormValues = z.infer<typeof githubFormSchema>;

export default function GitHubSettings() {
  const { data: profile, isLoading: profileLoading } = useProfile();
  const { data: repos, isLoading: reposLoading } = useGithubRepos();
  const syncGithubRepos = useSyncGithubRepos();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<GitHubFormValues>({
    resolver: zodResolver(githubFormSchema),
    defaultValues: {
      username: '',
    },
  });

  // Update form when profile data is loaded
  useState(() => {
    if (profile?.githubUsername) {
      form.reset({
        username: profile.githubUsername,
      });
    }
  });

  async function onSubmit(data: GitHubFormValues) {
    setIsSubmitting(true);
    try {
      await syncGithubRepos.mutateAsync(data.username);
      toast({
        title: 'GitHub synchronized',
        description: 'Your GitHub repositories have been successfully synchronized.',
      });
    } catch (error) {
      console.error('Failed to sync GitHub repos:', error);
      toast({
        title: 'Synchronization failed',
        description: 'There was a problem fetching your GitHub repositories. Please check the username and try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  const lastUpdated = repos && repos.length > 0 
    ? formatDistanceToNow(new Date(repos[0].updatedAt), { addSuffix: true })
    : null;

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>GitHub Integration</CardTitle>
            <CardDescription>
              Automatically fetch and display your latest GitHub repositories on your portfolio.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="username"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>GitHub Username</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="your-github-username" />
                  </FormControl>
                  <FormDescription>
                    Enter your GitHub username to display your repositories.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {lastUpdated && (
              <Alert className="bg-muted">
                <RefreshCw className="h-4 w-4" />
                <AlertTitle>Sync Status</AlertTitle>
                <AlertDescription>
                  Last synchronized {lastUpdated}. {repos?.length || 0} repositories found.
                </AlertDescription>
              </Alert>
            )}

            {!profileLoading && !profile?.githubUsername && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Not Configured</AlertTitle>
                <AlertDescription>
                  You haven't set up GitHub integration yet. Enter your GitHub username and click Synchronize.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button type="submit" disabled={isSubmitting || !form.formState.isDirty}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Synchronizing...
                </>
              ) : (
                <>
                  <Github className="mr-2 h-4 w-4" />
                  Synchronize Repositories
                </>
              )}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
