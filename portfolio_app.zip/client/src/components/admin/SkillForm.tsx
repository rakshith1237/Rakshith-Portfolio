import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useCreateSkill, useUpdateSkill } from '@/lib/hooks';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { insertSkillSchema, Skill } from '@shared/schema';

// Extend the schema with extra validation
const skillFormSchema = insertSkillSchema.extend({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  category: z.enum(['frontend', 'backend', 'tools']),
  proficiency: z.number().min(0).max(100),
});

type SkillFormValues = z.infer<typeof skillFormSchema>;

interface SkillFormProps {
  skill?: Skill;
  onComplete?: () => void;
}

export default function SkillForm({ skill, onComplete }: SkillFormProps) {
  const createSkill = useCreateSkill();
  const updateSkill = useUpdateSkill();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<SkillFormValues>({
    resolver: zodResolver(skillFormSchema),
    defaultValues: {
      name: skill?.name || '',
      category: skill?.category || 'frontend',
      proficiency: skill?.proficiency || 75,
      order: skill?.order || 0,
    },
  });

  async function onSubmit(data: SkillFormValues) {
    setIsSubmitting(true);
    try {
      if (skill) {
        // Update existing skill
        await updateSkill.mutateAsync({ id: skill.id, data });
        toast({
          title: 'Skill updated',
          description: 'The skill has been successfully updated.',
        });
      } else {
        // Create new skill
        await createSkill.mutateAsync(data);
        toast({
          title: 'Skill created',
          description: 'Your new skill has been successfully added.',
        });
        form.reset({
          name: '',
          category: 'frontend',
          proficiency: 75,
          order: 0,
        });
      }
      
      if (onComplete) {
        onComplete();
      }
    } catch (error) {
      console.error('Failed to save skill:', error);
      toast({
        title: 'Error',
        description: 'There was a problem saving the skill. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>{skill ? 'Edit Skill' : 'Add New Skill'}</CardTitle>
            <CardDescription>
              {skill 
                ? 'Update the details of your existing skill' 
                : 'Add a new skill to showcase in your portfolio'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Skill Name</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="E.g., React, Python, AWS" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="frontend">Frontend</SelectItem>
                      <SelectItem value="backend">Backend</SelectItem>
                      <SelectItem value="tools">Tools & Technologies</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Group your skills by category for better organization.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="proficiency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Proficiency ({field.value}%)</FormLabel>
                  <FormControl>
                    <Slider
                      min={0}
                      max={100}
                      step={1}
                      value={[field.value]}
                      onValueChange={([value]) => field.onChange(value)}
                      className="py-4"
                    />
                  </FormControl>
                  <FormDescription>
                    Rate your proficiency from 0% (beginner) to 100% (expert).
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="order"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Display Order</FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      type="number" 
                      onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                    />
                  </FormControl>
                  <FormDescription>
                    Lower numbers will display first within each category.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={() => onComplete?.()}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                skill ? 'Update Skill' : 'Add Skill'
              )}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </Form>
  );
}
