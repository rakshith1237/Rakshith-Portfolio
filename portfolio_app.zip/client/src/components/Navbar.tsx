import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useProfile } from '@/lib/hooks';
import { Button } from '@/components/ui/button';
import { useTheme } from '@/components/ui/theme-provider';
import { Sun, Moon, Menu, X, Download } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const { data: profile } = useProfile();
  const [location] = useLocation();

  // Close mobile menu when location changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <nav className="sticky top-0 z-50 bg-background border-b border-border shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <span className="text-primary font-bold text-xl cursor-pointer">DevPortfolio</span>
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <NavLink href="/" active={location === '/'}>
                Home
              </NavLink>
              <NavLink href="/#projects" active={false}>
                Projects
              </NavLink>
              <NavLink href="/#skills" active={false}>
                Skills
              </NavLink>
              <NavLink href="/#about" active={false}>
                About
              </NavLink>
              <NavLink href="/#contact" active={false}>
                Contact
              </NavLink>
            </div>
          </div>
          <div className="flex items-center">
            <div className="flex space-x-4">
              <Button
                variant="ghost"
                size="icon"
                className="rounded-full"
                onClick={toggleTheme}
                aria-label="Toggle theme"
              >
                {theme === 'dark' ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>
              
              <a href="/download" download>
                <Button variant="outline" className="gap-2 animated-button">
                  <Download className="h-4 w-4" />
                  Download
                </Button>
              </a>
              
              <Link href="/login">
                <Button>Admin Login</Button>
              </Link>
            </div>
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            <Button
              variant="ghost"
              className="inline-flex items-center justify-center"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Main menu"
              aria-expanded={isOpen}
            >
              {isOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <div className={cn(
        "sm:hidden transition-all duration-200 ease-in-out overflow-hidden",
        isOpen ? "max-h-60" : "max-h-0"
      )}>
        <div className="pt-2 pb-3 space-y-1">
          <MobileNavLink href="/" active={location === '/'}>
            Home
          </MobileNavLink>
          <MobileNavLink href="/#projects" active={false}>
            Projects
          </MobileNavLink>
          <MobileNavLink href="/#skills" active={false}>
            Skills
          </MobileNavLink>
          <MobileNavLink href="/#about" active={false}>
            About
          </MobileNavLink>
          <MobileNavLink href="/#contact" active={false}>
            Contact
          </MobileNavLink>
          <div className="px-4 py-2 border-t border-border mt-2 pt-2">
            <a href="/download" className="w-full">
              <Button className="w-full gap-2 animated-button">
                <Download className="h-4 w-4" />
                Download Portfolio
              </Button>
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}

interface NavLinkProps {
  href: string;
  active: boolean;
  children: React.ReactNode;
}

function NavLink({ href, active, children }: NavLinkProps) {
  return (
    <a 
      href={href}
      className={cn(
        "inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium",
        active 
          ? "border-primary text-foreground"
          : "border-transparent text-muted-foreground hover:border-border hover:text-foreground"
      )}
    >
      {children}
    </a>
  );
}

function MobileNavLink({ href, active, children }: NavLinkProps) {
  return (
    <a
      href={href}
      className={cn(
        "block pl-3 pr-4 py-2 border-l-4 text-base font-medium",
        active
          ? "bg-primary/10 border-primary text-primary"
          : "border-transparent text-muted-foreground hover:bg-muted hover:border-border"
      )}
    >
      {children}
    </a>
  );
}
