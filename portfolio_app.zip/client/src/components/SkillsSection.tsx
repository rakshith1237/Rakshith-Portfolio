import { useSkills, useTools } from '@/lib/hooks';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { LucideIcon, Code, SquareCode, Package, Monitor, Layers, CheckCircle, Zap, Flame } from 'lucide-react';

export default function SkillsSection() {
  const { data: skills, isLoading: skillsLoading } = useSkills();
  const { data: tools, isLoading: toolsLoading } = useTools();

  const frontendSkills = skills?.filter(skill => skill.category === 'frontend')
    .sort((a, b) => a.order - b.order) || [];
  
  const backendSkills = skills?.filter(skill => skill.category === 'backend')
    .sort((a, b) => a.order - b.order) || [];

  const getIconComponent = (iconName: string): LucideIcon => {
    switch (iconName) {
      case 'code': return Code;
      case 'code-block': return SquareCode;
      case 'package': return Package;
      case 'monitor': return Monitor;
      case 'layers': return Layers;
      case 'check-circle': return CheckCircle;
      case 'zap': return Zap;
      case 'flame': return Flame;
      default: return Code;
    }
  };

  if (skillsLoading || toolsLoading) {
    return (
      <section id="skills" className="relative py-20">
        <div className="section-container">
          <div className="text-center">
            <h2 className="gradient-text sm:text-4xl">
              My Skills
            </h2>
            <p className="mt-4 max-w-2xl text-xl text-muted-foreground mx-auto">
              Technologies and tools I work with.
            </p>
          </div>

          <div className="mt-16">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="portfolio-card">
                <h3 className="text-xl font-semibold text-foreground mb-6">Frontend Development</h3>
                <div className="space-y-5">
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={i}>
                      <div className="flex justify-between items-center mb-1">
                        <Skeleton className="h-5 w-32" />
                        <Skeleton className="h-4 w-12" />
                      </div>
                      <Skeleton className="h-2 w-full rounded" />
                    </div>
                  ))}
                </div>
              </div>

              <div className="portfolio-card">
                <h3 className="text-xl font-semibold text-foreground mb-6">Backend Development</h3>
                <div className="space-y-5">
                  {[1, 2, 3, 4, 5].map(i => (
                    <div key={i}>
                      <div className="flex justify-between items-center mb-1">
                        <Skeleton className="h-5 w-32" />
                        <Skeleton className="h-4 w-12" />
                      </div>
                      <Skeleton className="h-2 w-full rounded" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="skills" className="relative py-20">
      {/* Background decorative element */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -bottom-16 -right-16 w-64 h-64 bg-primary/10 rounded-full blur-3xl"></div>
        <div className="absolute top-32 -left-32 w-96 h-96 bg-accent/10 rounded-full blur-3xl"></div>
      </div>
      
      <div className="section-container relative z-10">
        <div className="text-center">
          <h2 className="gradient-text sm:text-4xl">
            My Skills
          </h2>
          <p className="mt-4 max-w-2xl text-xl text-muted-foreground mx-auto">
            Technologies and tools I work with.
          </p>
        </div>

        <div className="mt-16">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="portfolio-card">
              <h3 className="text-xl font-semibold text-foreground mb-6">Frontend Development</h3>
              <div className="space-y-6">
                {frontendSkills.map(skill => (
                  <div key={skill.id}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-base font-medium text-foreground">{skill.name}</span>
                      <span className="text-sm font-medium text-primary">{skill.proficiency}%</span>
                    </div>
                    <div className="skill-bar">
                      <div 
                        className="skill-progress" 
                        style={{ width: `${skill.proficiency}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="portfolio-card">
              <h3 className="text-xl font-semibold text-foreground mb-6">Backend Development</h3>
              <div className="space-y-6">
                {backendSkills.map(skill => (
                  <div key={skill.id}>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-base font-medium text-foreground">{skill.name}</span>
                      <span className="text-sm font-medium text-primary">{skill.proficiency}%</span>
                    </div>
                    <div className="skill-bar">
                      <div 
                        className="skill-progress" 
                        style={{ width: `${skill.proficiency}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {tools && tools.length > 0 && (
            <div className="mt-16">
              <div className="section-divider"></div>
              <h3 className="text-xl font-semibold text-foreground mt-10 mb-8 text-center">Tools & Technologies</h3>
              <div className="flex flex-wrap justify-center gap-3">
                {tools.map(tool => {
                  const IconComponent = getIconComponent(tool.icon);
                  return (
                    <div 
                      key={tool.id} 
                      className="bg-muted/60 backdrop-blur-sm px-5 py-3 rounded-lg flex items-center gap-2 border border-border shadow-sm hover:border-primary/30 hover:bg-muted/80 transition-all duration-300"
                    >
                      <IconComponent className="h-5 w-5 text-primary" />
                      <span className="text-foreground font-medium">{tool.name}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
