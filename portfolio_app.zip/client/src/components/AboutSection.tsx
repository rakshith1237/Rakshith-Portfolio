import { useProfile } from '@/lib/hooks';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Briefcase, Lightbulb, BookOpen, Users, Download } from 'lucide-react';

export default function AboutSection() {
  const { data: profile, isLoading } = useProfile();

  if (isLoading) {
    return (
      <section id="about" className="py-20 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
            <div className="mb-10 lg:mb-0">
              <Skeleton className="h-[600px] w-full rounded-xl" />
            </div>
            <div>
              <Skeleton className="h-12 w-40 mb-6" />
              <div className="space-y-4">
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-6 w-3/4" />
              </div>
            </div>
          </div>
        </div>
      </section>
    );
  }

  // Split long bio text into paragraphs
  const bioParagraphs = profile?.longBio?.split('\n\n') || [];

  return (
    <section id="about" className="py-20 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:grid lg:grid-cols-2 lg:gap-16 items-center">
          <div className="mb-10 lg:mb-0">
            <img 
              src="https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=700&h=600" 
              alt="Developer workspace with laptop" 
              className="rounded-xl shadow-xl"
            />
          </div>
          <div>
            <h2 className="text-3xl font-extrabold text-foreground sm:text-4xl">
              About Me
            </h2>
            <div className="mt-6 space-y-6 text-lg text-muted-foreground">
              {bioParagraphs.map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>
            
            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Briefcase className="h-12 w-12 text-primary" />
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium text-foreground">Professional</h4>
                  <p className="mt-1 text-base text-muted-foreground">5+ years of industry experience</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Lightbulb className="h-12 w-12 text-primary" />
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium text-foreground">Problem Solver</h4>
                  <p className="mt-1 text-base text-muted-foreground">Creative solutions to complex challenges</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <BookOpen className="h-12 w-12 text-primary" />
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium text-foreground">Continuous Learner</h4>
                  <p className="mt-1 text-base text-muted-foreground">Always exploring new technologies</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <Users className="h-12 w-12 text-primary" />
                </div>
                <div className="ml-4">
                  <h4 className="text-lg font-medium text-foreground">Team Player</h4>
                  <p className="mt-1 text-base text-muted-foreground">Collaborative approach to development</p>
                </div>
              </div>
            </div>
            
            {profile?.resumeUrl && (
              <div className="mt-10">
                <a href={profile.resumeUrl} download>
                  <Button className="group">
                    Download Resume
                    <Download className="ml-2 h-5 w-5 group-hover:translate-y-1 transition-transform duration-200" />
                  </Button>
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
