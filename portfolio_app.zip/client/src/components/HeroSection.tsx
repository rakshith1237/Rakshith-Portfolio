import { useState, useEffect } from 'react';
import { useProfile } from '@/lib/hooks';
import { Button } from '@/components/ui/button';
import { ChevronDown } from 'lucide-react';

export default function HeroSection() {
  const { data: profile, isLoading } = useProfile();
  const [typewriterText, setTypewriterText] = useState('');
  const [showCursor, setShowCursor] = useState(true);

  useEffect(() => {
    if (profile?.title) {
      let i = 0;
      const typeWriter = setInterval(() => {
        if (i < profile.title.length) {
          setTypewriterText(profile.title.substring(0, i + 1));
          i++;
        } else {
          clearInterval(typeWriter);
          
          // Blink cursor for a while, then stop
          setTimeout(() => {
            setShowCursor(false);
          }, 3000);
        }
      }, 100);
      
      return () => clearInterval(typeWriter);
    }
  }, [profile?.title]);

  if (isLoading) {
    return (
      <section className="py-20 md:py-28 lg:py-36 relative bg-gradient-to-b from-background via-background to-muted/50">
        <div className="section-container">
          <div className="w-full h-32 animate-pulse bg-muted rounded-lg"></div>
        </div>
      </section>
    );
  }

  return (
    <section id="home" className="py-20 md:py-28 lg:py-36 relative bg-gradient-to-b from-background via-background to-muted/50 overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-10 pointer-events-none">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-primary rounded-full filter blur-3xl opacity-20"></div>
        <div className="absolute top-1/3 -right-24 w-80 h-80 bg-accent rounded-full filter blur-3xl opacity-20"></div>
      </div>
      
      <div className="section-container relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          <div className="lg:w-1/2 lg:pr-12">
            <h1 className="leading-tight">
              <span className="block">Hi, I'm <span className="gradient-text">{profile?.name}</span></span>
              <span className={`block text-2xl md:text-3xl mt-2 text-muted-foreground ${showCursor ? 'after:content-["_"] after:border-r-2 after:border-primary after:ml-1 after:animate-[blink_0.7s_infinite]' : ''}`}>
                {typewriterText}
              </span>
            </h1>
            <p className="mt-6 text-xl text-muted-foreground max-w-2xl leading-relaxed">
              {profile?.shortBio}
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <a href="#projects">
                <Button size="lg" className="animated-button">
                  View My Work
                </Button>
              </a>
              <a href="#contact">
                <Button size="lg" variant="outline" className="hover:border-primary hover:text-primary transition-colors">
                  Contact Me
                </Button>
              </a>
            </div>
            
            {/* Optional social icons can go here */}
          </div>
          
          <div className="lg:w-1/2 relative">
            {profile?.profileImage ? (
              <div className="relative">
                {/* Profile image with decorative frame */}
                <div className="absolute inset-0 -m-4 rounded-2xl bg-gradient-to-tr from-primary via-primary/40 to-accent blur-xl opacity-20"></div>
                <img
                  src={profile.profileImage}
                  alt={`${profile.name} - Professional developer`}
                  className="relative rounded-2xl shadow-xl object-cover w-full max-w-md mx-auto border border-muted z-10"
                />
                
                {/* Decorative element */}
                <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-gradient-to-r from-primary to-accent rounded-md rotate-12 blur-sm opacity-60"></div>
              </div>
            ) : (
              <div className="w-full aspect-square max-w-md mx-auto bg-muted rounded-2xl opacity-50 flex items-center justify-center">
                <p className="text-center text-muted-foreground">Profile image will appear here</p>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-5 left-0 right-0 flex justify-center">
        <a 
          href="#projects" 
          className="text-muted-foreground hover:text-primary transition-colors p-2 rounded-full hover:bg-muted/50"
          aria-label="Scroll to projects section"
        >
          <ChevronDown className="h-6 w-6 animate-bounce" />
        </a>
      </div>
    </section>
  );
}
