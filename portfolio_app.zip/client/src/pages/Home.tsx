import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ProjectsSection from "@/components/ProjectsSection";
import GithubSection from "@/components/GithubSection";
import SkillsSection from "@/components/SkillsSection";
import AboutSection from "@/components/AboutSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import { Helmet } from 'react-helmet';
import { useProfile } from "@/lib/hooks";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const { data: profile } = useProfile();
  
  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>{profile?.name ? `${profile.name} | Portfolio` : 'DevPortfolio - Professional Web Developer'}</title>
        <meta name="description" content={profile?.shortBio || 'Professional web developer portfolio showcasing projects, skills and experience in web development.'} />
        <meta property="og:title" content={profile?.name ? `${profile.name} | Portfolio` : 'DevPortfolio'} />
        <meta property="og:description" content={profile?.shortBio || 'Professional web developer portfolio showcasing projects, skills and experience in web development.'} />
        <meta property="og:type" content="website" />
      </Helmet>
      
      <Navbar />
      
      <main className="flex-grow">
        <HeroSection />
        <ProjectsSection />
        <GithubSection />
        <SkillsSection />
        <AboutSection />
        <ContactSection />
      </main>
      
      <Footer />
      
      {/* Floating Download Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <a href="/download">
          <Button className="rounded-full shadow-lg animated-button p-4 h-auto w-auto">
            <Download className="h-6 w-6" />
            <span className="sr-only">Download Portfolio</span>
          </Button>
        </a>
      </div>
    </div>
  );
}
