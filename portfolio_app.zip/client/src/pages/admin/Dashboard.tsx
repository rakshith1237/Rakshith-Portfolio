import { useProfile, useProjects, useSkills, useGithubRepos } from "@/lib/hooks";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  User, 
  FolderKanban, 
  Award, 
  Github, 
  PencilLine, 
  Layers, 
  ExternalLink,
  BarChart3,
  Clock
} from "lucide-react";
import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";

export default function Dashboard() {
  const { data: profile, isLoading: profileLoading } = useProfile();
  const { data: projects, isLoading: projectsLoading } = useProjects();
  const { data: skills, isLoading: skillsLoading } = useSkills();
  const { data: githubRepos, isLoading: reposLoading } = useGithubRepos();

  const featuredSkills = skills?.filter(skill => skill.proficiency >= 90).slice(0, 3) || [];
  const latestProjects = projects?.slice(0, 3) || [];
  
  const getLastUpdateTime = () => {
    const dates: Date[] = [];
    
    if (profile) {
      // Add creation dates for various entities
      if (projects && projects.length > 0) {
        dates.push(new Date()); // Placeholder since we don't have actual timestamps
      }
    }
    
    if (dates.length === 0) return null;
    
    // Get the most recent date
    const mostRecent = new Date(Math.max(...dates.map(d => d.getTime())));
    return formatDistanceToNow(mostRecent, { addSuffix: true });
  };

  const lastUpdated = getLastUpdateTime();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">
            Welcome to your portfolio admin panel
            {lastUpdated && <span className="ml-2 text-sm">(Last updated: {lastUpdated})</span>}
          </p>
        </div>
        <Link href="/" target="_blank">
          <Button variant="outline" className="flex items-center gap-2">
            <ExternalLink className="h-4 w-4" />
            View Live Site
          </Button>
        </Link>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Projects</CardTitle>
            <FolderKanban className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{projectsLoading ? '...' : projects?.length || 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Skills Listed</CardTitle>
            <Award className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{skillsLoading ? '...' : skills?.length || 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">GitHub Repos</CardTitle>
            <Github className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reposLoading ? '...' : githubRepos?.length || 0}</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Profile Status</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {profileLoading ? '...' : profile?.name ? 'Complete' : 'Incomplete'}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Recent Projects</CardTitle>
            <CardDescription>
              Your most recently added projects
            </CardDescription>
          </CardHeader>
          <CardContent>
            {projectsLoading ? (
              <div className="text-muted-foreground">Loading projects...</div>
            ) : latestProjects.length > 0 ? (
              <div className="space-y-4">
                {latestProjects.map(project => (
                  <div key={project.id} className="flex items-center">
                    <div className="w-14 h-14 rounded bg-muted flex items-center justify-center mr-4 flex-shrink-0">
                      <Layers className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{project.title}</p>
                      <p className="text-sm text-muted-foreground truncate">{project.description}</p>
                    </div>
                    <Link href={`/admin/projects?edit=${project.id}`}>
                      <Button variant="ghost" size="icon">
                        <PencilLine className="h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-muted-foreground">No projects yet. Add your first project!</div>
            )}
            
            <div className="mt-4 pt-4 border-t">
              <Link href="/admin/projects">
                <Button variant="outline" size="sm" className="w-full">
                  View All Projects
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        <Card className="lg:row-span-2">
          <CardHeader>
            <CardTitle>Top Skills</CardTitle>
            <CardDescription>
              Your highest-rated skills
            </CardDescription>
          </CardHeader>
          <CardContent>
            {skillsLoading ? (
              <div className="text-muted-foreground">Loading skills...</div>
            ) : featuredSkills.length > 0 ? (
              <div className="space-y-4">
                {featuredSkills.map(skill => (
                  <div key={skill.id} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="font-medium">{skill.name}</div>
                      <div className="text-sm text-muted-foreground">{skill.proficiency}%</div>
                    </div>
                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary"
                        style={{ width: `${skill.proficiency}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-muted-foreground">No skills added yet. Add your first skill!</div>
            )}
            
            <div className="mt-4 pt-4 border-t">
              <Link href="/admin/skills">
                <Button variant="outline" size="sm" className="w-full">
                  Manage Skills
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks and updates</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link href="/admin/profile">
              <Button variant="outline" className="w-full justify-start">
                <User className="mr-2 h-4 w-4" />
                Update Profile
              </Button>
            </Link>
            
            <Link href="/admin/projects?new=true">
              <Button variant="outline" className="w-full justify-start">
                <FolderKanban className="mr-2 h-4 w-4" />
                Add New Project
              </Button>
            </Link>
            
            <Link href="/admin/skills?new=true">
              <Button variant="outline" className="w-full justify-start">
                <Award className="mr-2 h-4 w-4" />
                Add New Skill
              </Button>
            </Link>
            
            <Link href="/admin/github">
              <Button variant="outline" className="w-full justify-start">
                <Github className="mr-2 h-4 w-4" />
                Sync GitHub Repos
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
