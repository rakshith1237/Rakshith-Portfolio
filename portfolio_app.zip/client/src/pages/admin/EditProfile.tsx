import { useProfile } from "@/lib/hooks";
import ProfileForm from "@/components/admin/ProfileForm";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

export default function EditProfile() {
  const { isLoading } = useProfile();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Edit Profile</h1>
        <p className="text-muted-foreground">
          Update your personal information and contact details
        </p>
      </div>

      {isLoading ? (
        <Card className="p-6 space-y-6">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-6 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-36 w-full" />
        </Card>
      ) : (
        <ProfileForm />
      )}
    </div>
  );
}
