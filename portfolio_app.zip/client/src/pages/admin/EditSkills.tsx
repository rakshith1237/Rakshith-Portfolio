import { useState } from "react";
import { useSkills, useDeleteSkill } from "@/lib/hooks";
import { useLocation, useRoute } from "wouter";
import SkillForm from "@/components/admin/SkillForm";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2 } from "lucide-react";

export default function EditSkills() {
  const [_, params] = useRoute('/admin/skills:rest*');
  const [, navigate] = useLocation();
  const { data: skills, isLoading } = useSkills();
  const deleteSkill = useDeleteSkill();
  const { toast } = useToast();
  
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [skillToDelete, setSkillToDelete] = useState<number | null>(null);
  
  // Get query parameters
  const searchParams = new URLSearchParams(params?.rest || '');
  const showNewForm = searchParams.get('new') === 'true';
  const editSkillId = searchParams.get('edit');
  
  const skillToEdit = editSkillId 
    ? skills?.find(s => s.id === parseInt(editSkillId))
    : undefined;
  
  const handleCloseForm = () => {
    navigate('/admin/skills');
  };
  
  const confirmDelete = (skillId: number) => {
    setSkillToDelete(skillId);
    setIsDeleteDialogOpen(true);
  };
  
  const handleDelete = async () => {
    if (skillToDelete) {
      try {
        await deleteSkill.mutateAsync(skillToDelete);
        toast({
          title: "Skill deleted",
          description: "The skill has been successfully deleted.",
        });
      } catch (error) {
        console.error('Failed to delete skill:', error);
        toast({
          title: "Error",
          description: "Failed to delete the skill. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsDeleteDialogOpen(false);
        setSkillToDelete(null);
      }
    }
  };

  const getCategoryLabel = (category: string) => {
    switch (category) {
      case 'frontend': return 'Frontend';
      case 'backend': return 'Backend';
      case 'tools': return 'Tools & Technologies';
      default: return category;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Skills</h1>
          <p className="text-muted-foreground">
            Manage your skills and proficiency levels
          </p>
        </div>
        
        {!showNewForm && !editSkillId && (
          <Button onClick={() => navigate('/admin/skills?new=true')}>
            <Plus className="mr-2 h-4 w-4" />
            Add Skill
          </Button>
        )}
      </div>

      {showNewForm && (
        <SkillForm onComplete={handleCloseForm} />
      )}
      
      {editSkillId && skillToEdit && (
        <SkillForm 
          skill={skillToEdit} 
          onComplete={handleCloseForm} 
        />
      )}
      
      {!showNewForm && !editSkillId && (
        <Card>
          <CardHeader>
            <CardTitle>Your Skills</CardTitle>
            <CardDescription>
              A list of all skills and their proficiency levels
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-32 w-full" />
              </div>
            ) : skills?.length === 0 ? (
              <div className="text-center py-8">
                <h3 className="font-medium text-lg mb-2">No skills yet</h3>
                <p className="text-muted-foreground mb-4">
                  Add your first skill to showcase your expertise
                </p>
                <Button onClick={() => navigate('/admin/skills?new=true')}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Skill
                </Button>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Skill</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Proficiency</TableHead>
                      <TableHead className="text-center">Order</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {skills?.map((skill) => (
                      <TableRow key={skill.id}>
                        <TableCell className="font-medium">
                          {skill.name}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">
                            {getCategoryLabel(skill.category)}
                          </Badge>
                        </TableCell>
                        <TableCell className="w-[30%]">
                          <div className="flex items-center gap-2">
                            <Progress value={skill.proficiency} className="h-2" />
                            <span className="text-xs text-muted-foreground w-12">
                              {skill.proficiency}%
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-center">{skill.order}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => navigate(`/admin/skills?edit=${skill.id}`)}
                            >
                              <Pencil className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => confirmDelete(skill.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Are you sure?</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete the skill from your portfolio.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
