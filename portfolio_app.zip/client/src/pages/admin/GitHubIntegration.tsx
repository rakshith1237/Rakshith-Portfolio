import { useGithubRepos } from "@/lib/hooks";
import GitHubSettings from "@/components/admin/GitHubSettings";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Star, GitFork, Clock } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function GitHubIntegration() {
  const { data: repos, isLoading } = useGithubRepos();

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">GitHub Integration</h1>
        <p className="text-muted-foreground">
          Connect your GitHub account to showcase your repositories
        </p>
      </div>

      <GitHubSettings />

      <Card>
        <CardHeader>
          <CardTitle>Synchronized Repositories</CardTitle>
          <CardDescription>
            These repositories will be displayed in the GitHub section of your portfolio
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-4">
              <p className="text-muted-foreground">Loading repositories...</p>
            </div>
          ) : repos?.length === 0 ? (
            <div className="text-center py-4">
              <p className="text-muted-foreground">
                No repositories have been synchronized yet. Configure your GitHub username above.
              </p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Repository</TableHead>
                    <TableHead>Language</TableHead>
                    <TableHead>Topics</TableHead>
                    <TableHead>Stats</TableHead>
                    <TableHead>Last Updated</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {repos?.map(repo => (
                    <TableRow key={repo.id}>
                      <TableCell>
                        <div className="font-medium">{repo.name}</div>
                        <div className="text-sm text-muted-foreground truncate max-w-[300px]">
                          {repo.description || 'No description'}
                        </div>
                        <div className="mt-1">
                          <a 
                            href={repo.url} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-xs text-primary flex items-center hover:underline"
                          >
                            View Repository
                            <ExternalLink className="ml-1 h-3 w-3" />
                          </a>
                        </div>
                      </TableCell>
                      <TableCell>
                        {repo.language ? (
                          <Badge variant="outline">{repo.language}</Badge>
                        ) : (
                          <span className="text-xs text-muted-foreground">None</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {repo.topics && repo.topics.length > 0 ? (
                            repo.topics.slice(0, 3).map((topic, i) => (
                              <Badge key={i} variant="secondary" className="truncate max-w-[100px]">
                                {topic}
                              </Badge>
                            ))
                          ) : (
                            <span className="text-xs text-muted-foreground">No topics</span>
                          )}
                          {repo.topics && repo.topics.length > 3 && (
                            <Badge variant="outline">+{repo.topics.length - 3}</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center">
                            <Star className="h-4 w-4 mr-1 text-muted-foreground" />
                            <span>{repo.stars}</span>
                          </div>
                          <div className="flex items-center">
                            <GitFork className="h-4 w-4 mr-1 text-muted-foreground" />
                            <span>{repo.forks}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Clock className="h-3 w-3 mr-1" />
                          {formatDistanceToNow(new Date(repo.updatedAt), { addSuffix: true })}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
