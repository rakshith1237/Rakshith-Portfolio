import { useState } from "react";
import { useProjects, useDeleteProject } from "@/lib/hooks";
import { useLocation, useRoute } from "wouter";
import ProjectForm from "@/components/admin/ProjectForm";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Eye, Pencil, Plus, Trash2, X } from "lucide-react";

export default function EditProjects() {
  const [_, params] = useRoute('/admin/projects:rest*');
  const [, navigate] = useLocation();
  const { data: projects, isLoading } = useProjects();
  const deleteProject = useDeleteProject();
  const { toast } = useToast();
  
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState<number | null>(null);
  
  // Get query parameters
  const searchParams = new URLSearchParams(params?.rest || '');
  const showNewForm = searchParams.get('new') === 'true';
  const editProjectId = searchParams.get('edit');
  
  const projectToEdit = editProjectId 
    ? projects?.find(p => p.id === parseInt(editProjectId))
    : undefined;
  
  const handleCloseForm = () => {
    navigate('/admin/projects');
  };
  
  const confirmDelete = (projectId: number) => {
    setProjectToDelete(projectId);
    setIsDeleteDialogOpen(true);
  };
  
  const handleDelete = async () => {
    if (projectToDelete) {
      try {
        await deleteProject.mutateAsync(projectToDelete);
        toast({
          title: "Project deleted",
          description: "The project has been successfully deleted.",
        });
      } catch (error) {
        console.error('Failed to delete project:', error);
        toast({
          title: "Error",
          description: "Failed to delete the project. Please try again.",
          variant: "destructive",
        });
      } finally {
        setIsDeleteDialogOpen(false);
        setProjectToDelete(null);
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Projects</h1>
          <p className="text-muted-foreground">
            Manage your portfolio projects
          </p>
        </div>
        
        {!showNewForm && !editProjectId && (
          <Button onClick={() => navigate('/admin/projects?new=true')}>
            <Plus className="mr-2 h-4 w-4" />
            Add Project
          </Button>
        )}
      </div>

      {showNewForm && (
        <ProjectForm onComplete={handleCloseForm} />
      )}
      
      {editProjectId && projectToEdit && (
        <ProjectForm 
          project={projectToEdit} 
          onComplete={handleCloseForm} 
        />
      )}
      
      {!showNewForm && !editProjectId && (
        <Card>
          <CardHeader>
            <CardTitle>Your Projects</CardTitle>
            <CardDescription>
              A list of all projects in your portfolio
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-32 w-full" />
              </div>
            ) : projects?.length === 0 ? (
              <div className="text-center py-8">
                <h3 className="font-medium text-lg mb-2">No projects yet</h3>
                <p className="text-muted-foreground mb-4">
                  Add your first project to showcase your work
                </p>
                <Button onClick={() => navigate('/admin/projects?new=true')}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Project
                </Button>
              </div>
            ) : (
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Tags</TableHead>
                      <TableHead className="text-center">Order</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projects?.map((project) => (
                      <TableRow key={project.id}>
                        <TableCell className="font-medium">
                          {project.title}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {project.tags.slice(0, 3).map((tag, i) => (
                              <Badge key={i} variant="secondary" className="truncate max-w-[100px]">
                                {tag}
                              </Badge>
                            ))}
                            {project.tags.length > 3 && (
                              <Badge variant="outline">+{project.tags.length - 3}</Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-center">{project.order}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            {project.demoUrl && (
                              <Button variant="ghost" size="icon" asChild>
                                <a href={project.demoUrl} target="_blank" rel="noopener noreferrer">
                                  <Eye className="h-4 w-4" />
                                  <span className="sr-only">View Demo</span>
                                </a>
                              </Button>
                            )}
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => navigate(`/admin/projects?edit=${project.id}`)}
                            >
                              <Pencil className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={() => confirmDelete(project.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Are you sure?</DialogTitle>
            <DialogDescription>
              This action cannot be undone. This will permanently delete the project from your portfolio.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDelete}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
