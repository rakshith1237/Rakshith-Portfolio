import { Switch, Route, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Dashboard from "@/pages/admin/Dashboard";
import EditProfile from "@/pages/admin/EditProfile";
import EditProjects from "@/pages/admin/EditProjects";
import EditSkills from "@/pages/admin/EditSkills";
import GitHubIntegration from "@/pages/admin/GitHubIntegration";
import AdminLayout from "@/components/admin/AdminLayout";
import { useEffect } from "react";

function AdminRoutes() {
  // Fetch current user to check authentication
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/auth/user'],
  });
  
  const [, setLocation] = useLocation();

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !data) {
      setLocation('/login');
    }
  }, [data, isLoading, setLocation]);

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  if (error || !data) {
    return null; // Will redirect to login via the useEffect
  }

  return (
    <AdminLayout>
      <Switch>
        <Route path="/admin" component={Dashboard} />
        <Route path="/admin/profile" component={EditProfile} />
        <Route path="/admin/projects" component={EditProjects} />
        <Route path="/admin/skills" component={EditSkills} />
        <Route path="/admin/github" component={GitHubIntegration} />
        <Route component={NotFound} />
      </Switch>
    </AdminLayout>
  );
}

function App() {
  return (
    <TooltipProvider>
      <Toaster />
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/login" component={Login} />
        <Route path="/admin/:rest*">
          <AdminRoutes />
        </Route>
        <Route component={NotFound} />
      </Switch>
    </TooltipProvider>
  );
}

export default App;
