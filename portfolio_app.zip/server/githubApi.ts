import fetch from 'node-fetch';
import { InsertGithubRepo } from '@shared/schema';

export async function fetchUserRepositories(username: string): Promise<InsertGithubRepo[]> {
  try {
    // GitHub API URL for user's repositories
    const url = `https://api.github.com/users/${username}/repos?sort=updated&direction=desc&per_page=10`;
    
    // Add GitHub token if available for higher rate limits
    const headers: HeadersInit = {
      'Accept': 'application/vnd.github.v3+json'
    };
    
    if (process.env.GITHUB_TOKEN) {
      headers['Authorization'] = `token ${process.env.GITHUB_TOKEN}`;
    }
    
    const response = await fetch(url, { headers });
    
    if (!response.ok) {
      throw new Error(`GitHub API returned ${response.status}: ${response.statusText}`);
    }
    
    const repos = await response.json() as any[];
    
    // Transform GitHub API response to our schema
    return repos.map(repo => ({
      name: repo.name,
      description: repo.description || '',
      url: repo.html_url,
      stars: repo.stargazers_count,
      forks: repo.forks_count,
      language: repo.language || null,
      topics: repo.topics || [],
      updatedAt: new Date(repo.updated_at)
    }));
    
  } catch (error) {
    console.error('Error fetching GitHub repositories:', error);
    throw error;
  }
}
