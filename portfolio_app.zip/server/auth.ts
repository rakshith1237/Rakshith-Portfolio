import { Request, Response, NextFunction } from 'express';
import { compare, hash } from 'bcrypt';
import { storage } from './storage';
import { insertUserSchema } from '@shared/schema';

const SALT_ROUNDS = 10;

export async function hashPassword(password: string): Promise<string> {
  return hash(password, SALT_ROUNDS);
}

export async function comparePassword(password: string, hashedPassword: string): Promise<boolean> {
  return compare(password, hashedPassword);
}

export async function initializeAdmin(): Promise<void> {
  // Check if admin user exists
  const adminUser = await storage.getUserByUsername('admin');
  if (!adminUser) {
    // Create default admin user if none exists
    const password = process.env.ADMIN_PASSWORD || 'admin123';
    const hashedPassword = await hashPassword(password);
    
    const userData = {
      username: 'admin',
      password: hashedPassword,
    };
    
    await storage.createUser(userData);
    console.log('Default admin user created');
  }
}

export function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.session && req.session.userId) {
    return next();
  }
  res.status(401).json({ message: 'Unauthorized' });
}

export async function login(req: Request, res: Response) {
  try {
    const { username, password } = req.body;
    
    // Validate input
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }
    
    // Find user
    const user = await storage.getUserByUsername(username);
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    // Check password
    const passwordMatch = await comparePassword(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    // Set session
    if (req.session) {
      req.session.userId = user.id;
      req.session.username = user.username;
    }
    
    res.json({ 
      message: 'Login successful',
      user: { id: user.id, username: user.username }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}

export function logout(req: Request, res: Response) {
  if (req.session) {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: 'Failed to logout' });
      }
      res.json({ message: 'Logout successful' });
    });
  } else {
    res.json({ message: 'Already logged out' });
  }
}

export async function getCurrentUser(req: Request, res: Response) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ message: 'Not authenticated' });
  }
  
  try {
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      // Session exists but user doesn't - clear session
      req.session.destroy(() => {});
      return res.status(401).json({ message: 'User not found' });
    }
    
    res.json({ 
      user: { 
        id: user.id, 
        username: user.username 
      } 
    });
  } catch (error) {
    console.error('Get current user error:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
}
