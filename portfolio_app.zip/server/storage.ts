import { 
  User, InsertUser, 
  Profile, InsertProfile,
  Project, InsertProject,
  Skill, InsertSkill,
  SocialLink, InsertSocialLink,
  GithubRepo, InsertGithubRepo,
  Tool, InsertTool,
  users, profile, projects, skills, socialLinks, githubRepos, tools
} from '@shared/schema';
import { db } from './db';
import { eq, desc, asc } from 'drizzle-orm';

// Define the IStorage interface that both implementations will follow

export interface IStorage {
  // User authentication
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Profile management
  getProfile(): Promise<Profile | null>;
  updateProfile(profile: InsertProfile): Promise<Profile>;

  // Project management
  getProjects(): Promise<Project[]>;
  getProject(id: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: number, project: Partial<InsertProject>): Promise<Project>;
  deleteProject(id: number): Promise<boolean>;

  // Skills management
  getSkills(): Promise<Skill[]>;
  getSkill(id: number): Promise<Skill | undefined>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  updateSkill(id: number, skill: Partial<InsertSkill>): Promise<Skill>;
  deleteSkill(id: number): Promise<boolean>;

  // Tools management
  getTools(): Promise<{ id: number; name: string; icon: string }[]>;

  // Social links management
  getSocialLinks(): Promise<SocialLink[]>;
  getSocialLink(id: number): Promise<SocialLink | undefined>;
  createSocialLink(socialLink: InsertSocialLink): Promise<SocialLink>;
  updateSocialLink(id: number, socialLink: Partial<InsertSocialLink>): Promise<SocialLink>;
  deleteSocialLink(id: number): Promise<boolean>;

  // GitHub repos management
  getGithubRepos(): Promise<GithubRepo[]>;
  updateGithubRepos(repos: InsertGithubRepo[]): Promise<GithubRepo[]>;
}

export class DatabaseStorage implements IStorage {
  // Users methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Profile methods
  async getProfile(): Promise<Profile | null> {
    const [profileData] = await db.select().from(profile);
    return profileData || null;
  }

  async updateProfile(profileData: InsertProfile): Promise<Profile> {
    // Check if profile exists
    const existingProfile = await this.getProfile();
    
    if (existingProfile) {
      // Update existing profile
      const [updatedProfile] = await db
        .update(profile)
        .set(profileData)
        .where(eq(profile.id, existingProfile.id))
        .returning();
      return updatedProfile;
    } else {
      // Create new profile with id 1
      const [newProfile] = await db
        .insert(profile)
        .values({ ...profileData, id: 1 })
        .returning();
      return newProfile;
    }
  }

  // Projects methods
  async getProjects(): Promise<Project[]> {
    return db.select().from(projects).orderBy(asc(projects.order));
  }

  async getProject(id: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async updateProject(id: number, project: Partial<InsertProject>): Promise<Project> {
    const [updatedProject] = await db
      .update(projects)
      .set(project)
      .where(eq(projects.id, id))
      .returning();
    
    if (!updatedProject) {
      throw new Error(`Project with id ${id} not found`);
    }
    
    return updatedProject;
  }

  async deleteProject(id: number): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return result.rowCount > 0;
  }

  // Skills methods
  async getSkills(): Promise<Skill[]> {
    // First sort by category, then by order within category
    return db
      .select()
      .from(skills)
      .orderBy(asc(skills.category), asc(skills.order));
  }

  async getSkill(id: number): Promise<Skill | undefined> {
    const [skill] = await db.select().from(skills).where(eq(skills.id, id));
    return skill;
  }

  async createSkill(skill: InsertSkill): Promise<Skill> {
    const [newSkill] = await db.insert(skills).values(skill).returning();
    return newSkill;
  }

  async updateSkill(id: number, skill: Partial<InsertSkill>): Promise<Skill> {
    const [updatedSkill] = await db
      .update(skills)
      .set(skill)
      .where(eq(skills.id, id))
      .returning();
    
    if (!updatedSkill) {
      throw new Error(`Skill with id ${id} not found`);
    }
    
    return updatedSkill;
  }

  async deleteSkill(id: number): Promise<boolean> {
    const result = await db.delete(skills).where(eq(skills.id, id));
    return result.rowCount > 0;
  }

  // Tools methods
  async getTools(): Promise<{ id: number; name: string; icon: string }[]> {
    return db.select().from(tools);
  }

  // Social links methods
  async getSocialLinks(): Promise<SocialLink[]> {
    return db.select().from(socialLinks).orderBy(asc(socialLinks.order));
  }

  async getSocialLink(id: number): Promise<SocialLink | undefined> {
    const [link] = await db.select().from(socialLinks).where(eq(socialLinks.id, id));
    return link;
  }

  async createSocialLink(socialLink: InsertSocialLink): Promise<SocialLink> {
    const [newLink] = await db.insert(socialLinks).values(socialLink).returning();
    return newLink;
  }

  async updateSocialLink(id: number, socialLink: Partial<InsertSocialLink>): Promise<SocialLink> {
    const [updatedLink] = await db
      .update(socialLinks)
      .set(socialLink)
      .where(eq(socialLinks.id, id))
      .returning();
    
    if (!updatedLink) {
      throw new Error(`Social link with id ${id} not found`);
    }
    
    return updatedLink;
  }

  async deleteSocialLink(id: number): Promise<boolean> {
    const result = await db.delete(socialLinks).where(eq(socialLinks.id, id));
    return result.rowCount > 0;
  }

  // GitHub repos methods
  async getGithubRepos(): Promise<GithubRepo[]> {
    return db.select().from(githubRepos);
  }

  async updateGithubRepos(repos: InsertGithubRepo[]): Promise<GithubRepo[]> {
    // First delete all existing repos
    await db.delete(githubRepos);
    
    // Then insert the new ones
    if (repos.length === 0) {
      return [];
    }
    
    return db.insert(githubRepos).values(repos).returning();
  }
}

export const storage = new DatabaseStorage();
