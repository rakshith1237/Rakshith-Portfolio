import type { Express, Request, Response, NextFunction } from 'express';
import { createServer, type Server } from 'http';
import session from 'express-session';
import * as bcrypt from 'bcrypt';
import { storage } from './storage';
import {
  insertProfileSchema,
  insertProjectSchema,
  insertSkillSchema,
  insertSocialLinkSchema
} from '@shared/schema';
import { isAuthenticated, login, logout, getCurrentUser, initializeAdmin } from './auth';
import { fetchUserRepositories } from './githubApi';
import { execSync } from 'child_process';
import path from 'path';
import fs from 'fs';

declare module 'express-session' {
  interface SessionData {
    userId: number;
    username: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure session
  app.use(session({
    secret: process.env.SESSION_SECRET || 'portfolio-secret',
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === 'production',
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Initialize admin user
  await initializeAdmin();

  // Authentication routes
  app.post('/api/auth/login', login);
  app.post('/api/auth/logout', logout);
  app.get('/api/auth/user', getCurrentUser);

  // Public API routes
  // Profile
  app.get('/api/profile', async (req: Request, res: Response) => {
    try {
      const profile = await storage.getProfile();
      res.json(profile);
    } catch (error) {
      console.error('Error getting profile:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Projects
  app.get('/api/projects', async (req: Request, res: Response) => {
    try {
      const projects = await storage.getProjects();
      res.json(projects);
    } catch (error) {
      console.error('Error getting projects:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Skills
  app.get('/api/skills', async (req: Request, res: Response) => {
    try {
      const skills = await storage.getSkills();
      res.json(skills);
    } catch (error) {
      console.error('Error getting skills:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Tools
  app.get('/api/tools', async (req: Request, res: Response) => {
    try {
      const tools = await storage.getTools();
      res.json(tools);
    } catch (error) {
      console.error('Error getting tools:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Social Links
  app.get('/api/social-links', async (req: Request, res: Response) => {
    try {
      const links = await storage.getSocialLinks();
      res.json(links);
    } catch (error) {
      console.error('Error getting social links:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // GitHub Repos
  app.get('/api/github-repos', async (req: Request, res: Response) => {
    try {
      const repos = await storage.getGithubRepos();
      res.json(repos);
    } catch (error) {
      console.error('Error getting GitHub repos:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Protected Admin API routes
  // Update Profile
  app.put('/api/admin/profile', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const profileData = await insertProfileSchema.parseAsync(req.body);
      const updatedProfile = await storage.updateProfile(profileData);
      res.json(updatedProfile);
    } catch (error) {
      console.error('Error updating profile:', error);
      res.status(400).json({ message: 'Invalid profile data' });
    }
  });

  // Projects CRUD
  app.post('/api/admin/projects', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const projectData = await insertProjectSchema.parseAsync(req.body);
      const newProject = await storage.createProject(projectData);
      res.status(201).json(newProject);
    } catch (error) {
      console.error('Error creating project:', error);
      res.status(400).json({ message: 'Invalid project data' });
    }
  });

  app.put('/api/admin/projects/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid project ID' });
      }

      const project = await storage.getProject(id);
      if (!project) {
        return res.status(404).json({ message: 'Project not found' });
      }

      const projectData = req.body;
      const updatedProject = await storage.updateProject(id, projectData);
      res.json(updatedProject);
    } catch (error) {
      console.error('Error updating project:', error);
      res.status(400).json({ message: 'Invalid project data' });
    }
  });

  app.delete('/api/admin/projects/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid project ID' });
      }

      const success = await storage.deleteProject(id);
      if (success) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: 'Project not found' });
      }
    } catch (error) {
      console.error('Error deleting project:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Skills CRUD
  app.post('/api/admin/skills', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const skillData = await insertSkillSchema.parseAsync(req.body);
      const newSkill = await storage.createSkill(skillData);
      res.status(201).json(newSkill);
    } catch (error) {
      console.error('Error creating skill:', error);
      res.status(400).json({ message: 'Invalid skill data' });
    }
  });

  app.put('/api/admin/skills/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid skill ID' });
      }

      const skill = await storage.getSkill(id);
      if (!skill) {
        return res.status(404).json({ message: 'Skill not found' });
      }

      const skillData = req.body;
      const updatedSkill = await storage.updateSkill(id, skillData);
      res.json(updatedSkill);
    } catch (error) {
      console.error('Error updating skill:', error);
      res.status(400).json({ message: 'Invalid skill data' });
    }
  });

  app.delete('/api/admin/skills/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid skill ID' });
      }

      const success = await storage.deleteSkill(id);
      if (success) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: 'Skill not found' });
      }
    } catch (error) {
      console.error('Error deleting skill:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // Social Links CRUD
  app.post('/api/admin/social-links', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const linkData = await insertSocialLinkSchema.parseAsync(req.body);
      const newLink = await storage.createSocialLink(linkData);
      res.status(201).json(newLink);
    } catch (error) {
      console.error('Error creating social link:', error);
      res.status(400).json({ message: 'Invalid social link data' });
    }
  });

  app.put('/api/admin/social-links/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid social link ID' });
      }

      const link = await storage.getSocialLink(id);
      if (!link) {
        return res.status(404).json({ message: 'Social link not found' });
      }

      const linkData = req.body;
      const updatedLink = await storage.updateSocialLink(id, linkData);
      res.json(updatedLink);
    } catch (error) {
      console.error('Error updating social link:', error);
      res.status(400).json({ message: 'Invalid social link data' });
    }
  });

  app.delete('/api/admin/social-links/:id', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid social link ID' });
      }

      const success = await storage.deleteSocialLink(id);
      if (success) {
        res.status(204).end();
      } else {
        res.status(404).json({ message: 'Social link not found' });
      }
    } catch (error) {
      console.error('Error deleting social link:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  // GitHub Integration
  app.post('/api/admin/github-sync', isAuthenticated, async (req: Request, res: Response) => {
    try {
      const { username } = req.body;
      if (!username) {
        return res.status(400).json({ message: 'GitHub username is required' });
      }

      // Fetch repos from GitHub API
      const repos = await fetchUserRepositories(username);
      
      // Save repos to storage
      const savedRepos = await storage.updateGithubRepos(repos);
      
      // Update profile with GitHub username
      const profile = await storage.getProfile();
      if (profile) {
        await storage.updateProfile({ ...profile, githubUsername: username });
      }
      
      res.json(savedRepos);
    } catch (error) {
      console.error('Error syncing GitHub repos:', error);
      res.status(500).json({ message: 'Failed to sync GitHub repositories' });
    }
  });
  
  // Download application route
  app.get('/download', async (req: Request, res: Response) => {
    try {
      const rootDir = process.cwd();
      const zipFilePath = path.join(rootDir, 'portfolio_app.zip');
      
      // Create a zip file of the project, excluding node_modules and hidden files
      console.log('Creating zip file...');
      execSync(`cd ${rootDir} && zip -r ${zipFilePath} . -x "node_modules/*" ".*"`, { stdio: 'inherit' });
      
      // Set headers for file download
      res.setHeader('Content-Disposition', 'attachment; filename=portfolio_app.zip');
      res.setHeader('Content-Type', 'application/zip');
      
      // Stream the file to the response
      const fileStream = fs.createReadStream(zipFilePath);
      fileStream.pipe(res);
      
      // Clean up the zip file after download completes
      fileStream.on('end', () => {
        fs.unlinkSync(zipFilePath);
      });
      
    } catch (error) {
      console.error('Error creating download:', error);
      res.status(500).send('Failed to create download file. Please try again.');
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
